# Handoff: Lumi Dashboard Redesign

## Overview
A redesign of three Lumi dashboard screens, focused on reducing overwhelm: a collapsible Discord-style category sidebar shared across all of them, a triage-first "Needs attention" panel on Overview, a full Modules grid on its own page, and a dedicated Security module page (panic mode, anti-nuke, join gate, backups). Roles/log-channel fields and mention-spam settings were removed from Overview's Core settings — those now belong on each module's own settings page (Modules, Security).

## About the Design Files
The files in this bundle (`Current.html`, `Redesign.html`) are **design references built in HTML** — static prototypes showing intended layout, color, type, and interaction, not production code to copy directly. The task is to **recreate this design inside the existing Next.js/React/Tailwind dashboard app**, using its existing component library (`components/ui/*`, `components/layout/*`, `components/guild/*`) and existing data-fetching patterns — not to ship this HTML as-is.

## Fidelity
**High-fidelity.** Colors, spacing, and type are final and pulled directly from the app's real design tokens (`apps/dashboard/src/app/globals.css` — the "Daylight" cobalt/graphite system). Copy text is representative sample data, not final content — wire it to real guild data.

## Screens / Views

### Shared shell (all screens)
Left sidebar (266px, sticky) + sticky glass header, identical across Overview/Modules/Security — implement once as a layout component. Nav: Overview/Modules/Addons flat, then collapsible category groups (Moderation, Security, Community, System) each with a count badge and a red/amber dot when something in that category needs attention. The active page's nav item gets `--primary-soft` background + bold `--btn-content` text.

### Guild Overview (redesigned)
**Purpose:** Give a server owner/mod a fast read on what needs action, then let them adjust the handful of settings almost everyone touches, without wading through all 14 Core fields or 9 module cards.

**Layout**
- Outer shell: `display:flex; gap:14px; padding:14px`, `min-width:1200px` (desktop-only tool, not responsive below that).
- Left sidebar: fixed `266px`, sticky (`top:14px`), rounded panel (`--radius-large` = 20px), own scroll.
- Main column: `flex:1`, containing a sticky glass header, then a two-column grid `minmax(0,1fr) 19rem` (main content + right rail), `gap:14px`.

**Components**
1. **Sidebar** — brand mark + theme toggle row; guild switcher button; nav grouped as Overview/Modules/Addons (flat), then collapsible category groups: Moderation, Security, Community, System — each a header button (chevron + label + count badge) that expands/collapses a sub-list. Security and System sub-items carry a small red dot when something in that category needs attention. User row pinned to the bottom via `margin-top:auto`.
2. **Header** — sticky, frosted glass (`backdrop-filter: blur(20px) saturate(160%)`, translucent bg), search field (⌘K), a "panic mode armed" status pill, a System link button.
3. **Needs attention panel** — the triage-first block, top of main column. Icon + title + "N critical" count. Two always-visible critical rows (panic armed, shard down) each with inline actions (Revert now / Details / Open fleet). A "Show N more" button expands four more warning-level rows (raid detected, missing permission, filter killed globally, config drift from Discord). Each row: icon (tinted by severity), bold one-line summary, one sentence of context, right-aligned action button.
4. **Modules status strip** — a single-line compact card (not a grid): "Modules · 7 of 9 on · Filter killed globally · Security 2 alerts" + "Manage modules →" link. Full module management now lives on its own page (out of scope for this handoff — see Modules page).
5. **Core settings panel** — header + one-sentence explanation. Essentials grid (3 fields: Command prefix, Locale, Timezone) always visible. "Advanced" disclosure button (chevron + label + "2 settings · mute role, ignored channels") reveals a 2-column grid (Mute role, Ignored channels) with a fade-in on expand. Sticky save bar at the bottom: "Unsaved changes on 1 field" + Reset/Save changes buttons.
6. **Right rail** — three stacked cards: "This server" stat list (members, modules on, open cases, appeals waiting), "Shard fleet" 4-cell status grid, "Recent changes" activity feed (colored dot + description + actor/source/time) with a "Full settings history" link.

**Typography & color** — see Design Tokens below; all values are the dashboard's real tokens, not invented ones.

**Hover/active/focus states**
- Buttons: background tint on hover (`--btn-*-hover` tokens), `scale(0.96)` on press, spring easing `cubic-bezier(0.34,1.56,0.64,1)` on the primary/danger buttons' press transform.
- Cards get a `translateY(-3px)` lift + `--shadow-md` on hover.
- Primary "Save changes" gets an accent-glow shadow (`--shadow-accent`) + `translateY(-1px)` on hover; "Revert now" gets the same treatment in the caution/danger hue.
- Nav sub-groups fade+slide in on expand (`opacity 0→1, translateY` over ~220ms, `cubic-bezier(0.22,1,0.36,1)`).
- Focus states: rely on the app's existing global `:focus-visible { outline: 2px solid var(--ring) }` — not reinvented here.

### Modules (new page)
**Purpose:** Turn features on/off and see at a glance which modules need attention, without that living on Overview.
**Layout:** Page header (title + one-line description + "N of 9 on" count) then a 3-column card grid, one card per module.
**Components per card:** icon tile, on/off toggle (or "always on" pill for Core), module name (links to that module's settings page), one-sentence description, a meta line (field count + version, or a status override like "killed globally" / "2 alerts · 22 settings" in warning/caution color). Cards with an active alert get a thin caution-colored border.
**States:** hover lifts the card (`translateY(-3px)` + `--shadow-md`); toggle switch flips with a spring easing on the knob.

### Security (new page — one module's dedicated settings)
**Purpose:** The full anti-nuke/join-gate/panic-mode/backup surface for the Security module, reached from Modules or the sidebar's Security category.
**Layout:** Page header (title + description + master on/off toggle), then a stacked single column: panic-mode status banner → Anti-nuke card (description + inline permission-missing warning + a response-per-action-type table) → Join gate & verification card (2×2 toggle grid + a live "raid active, N held" status row) → Backups card (last-snapshot time + restore action).
**Components:** panic banner uses `--caution-bg` fill, a live-pulsing dot, and a "Revert now" button with an accent/caution glow shadow on hover. The anti-nuke table's Response column uses colored pills (ban=caution, quarantine=warning, log only=neutral). Join-gate toggles are a plain 2-column grid of label + switch rows on `--codeblock-bg`.

## Interactions & Behavior
- **Sidebar category groups** (Moderation/Security/Community/System) are independently collapsible; default state: Moderation and Security open, Community and System collapsed (the two categories with active alerts start open).
- **Needs-attention list**: 2 rows shown by default (both severity "critical"), 4 more behind "Show 4 more". No auto-dismiss; a "Details"/action button per row routes to the relevant page (fleet status, permissions, kill switches, settings diff).
- **Core settings → Advanced**: single disclosure toggle, closed by default. Opening reveals 2 fields with a quick fade/slide-in (240ms).
- **Theme toggle**: rotates 25° on hover as a hint it's interactive; actual toggle sets `data-theme` light/dark (this prototype's theme values mirror the app's real dark-mode tokens).
- **Save bar**: appears whenever there's a dirty field; in the real app this should track actual form dirty-state per the existing `save-bar.tsx` pattern already in the codebase — don't reinvent that plumbing, just restyle it to match.

## State Management
- Sidebar group open/closed: 4 booleans (mod/sec/com/sys), plus 1 for the Core "Advanced" disclosure, plus 1 for "Needs attention" expanded/collapsed. All local UI state — no need to persist beyond the session unless the real app already persists nav-group state.
- Needs-attention items, shard health, module on/off + alert counts, recent-changes feed, and the stat rail should all come from real guild data (existing dashboard data-fetching patterns) — this prototype hardcodes sample values.

## Design Tokens
Pulled directly from `apps/dashboard/src/app/globals.css` (the app's real "Daylight" theme) — do not introduce new values.

**Light**
- `--bg:#f4f5f8` `--bg-subtle:#ebedf2` `--surface:#ffffff` `--surface-hover:#f5f6fa`
- `--border:#e1e4ea` `--border-soft:#ebedf2`
- `--fg:#14161c` `--fg-muted:#5a6270` `--fg-subtle:#8b93a3`
- `--accent:#2953d8` `--accent-hover:#1f41b0` `--accent-soft:rgba(41,83,216,0.09)`
- `--success:#12805a` `--warning:#92600a` `--danger:#c7333f`

**Dark**
- `--bg:#0a0b0f` `--surface:#15171d` `--surface-hover:#1b1e25`
- `--border:#262931` `--fg:#ecedf2` `--fg-muted:#969caa` `--fg-subtle:#5f6572`
- `--accent:#5b8cff` `--accent-hover:#7ba3ff`
- `--success:#34d399` `--warning:#fbbf24` `--danger:#fb7185`

**Shape/motion**
- Radius: control `12px`, panel `20px`, pill `999px`.
- Shadows: `--shadow-card` (barely-there), `--shadow-md`, `--shadow-lg`, `--shadow-accent` (accent-tinted glow for the primary action).
- Motion: `120–150ms` for hovers, `220–320ms` for reveals, easing `cubic-bezier(0.22,1,0.36,1)` (settled, no bounce) except button-press which uses a slight spring `cubic-bezier(0.34,1.56,0.64,1)`.
- Fonts: `--font-display`/`--font-sans` = Geist (self-hosted via `next/font`) falling back to system UI font stack; `--font-mono` = JetBrains Mono, used for all counts, IDs, timestamps, code-like values (`font-variant-numeric: tabular-nums` on numeric columns).

## Assets
Icons are Material Symbols via Iconify (`material-symbols:*` icon names) — matches the icon set already used in the app's design language (confirm against `components/ui/glyph.tsx` for the app's actual icon-loading approach, which may differ from the CDN `<iconify-icon>` tag used in this HTML prototype).

## Files
- `Current.html` — pixel-accurate recreation of the *existing* production overview page, for side-by-side comparison.
- `Redesign.html` — the redesigned guild-overview page.
- `Modules.html` — the new Modules page.
- `Security.html` — the new Security module settings page.
